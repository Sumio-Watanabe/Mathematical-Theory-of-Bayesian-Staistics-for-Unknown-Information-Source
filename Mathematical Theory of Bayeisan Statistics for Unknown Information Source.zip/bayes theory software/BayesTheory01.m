clear;
%%%%% Matrix Factorization Adjusted Cross Validation
rng(1);

n=200;
n1=100;
n2=n-n1;
nt=3000;
M=8;
N=8;
HMAX=6;
H0=2;
sigma=1;
rho=10;
mu=10;
beta=1;
KKK=2000;
TTT=200;
BURNIN=100;

CCCCC=(2*pi*sigma^2)^(M*N/2);
prob=@(AB,X)(CCCCC*exp(-sum(sum((X-AB).^2))/(2*sigma^2)));



A0B0=zeros(M,N);
for i=1:1:H0
    A0B0(i,i)=1;
end

for ttt=1:1:TTT
    
  for i=1:1:nt
      XT(i,:,:)=sigma*randn(M,N)+A0B0;
      XXT=reshape(XT(i,:,:),[M,N]);
      sst(i)=-log(prob(A0B0,XXT));
  end
  for i=1:1:n
    X(i,:,:)=sigma*randn(M,N)+A0B0;
    XX=reshape(X(i,:,:),[M,N]);
    sss(i)=-log(prob(A0B0,XX));
  end
  X1=X(1:1:n1,:,:);
  X2=X(n1+1:1:n,:,:);
  sss1=sss(1,1:1:n1);
  sss2=sss(1,n1+1:1:n);
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
  for mmm=1:1:2
    if(mmm==1)
        H=H0;
    else
        H=HMAX;
    end
    [RA RB]=gibbs(X,n,M,N,H,KKK,BURNIN,rho,mu,sigma,beta);
    EA=reshape(mean(RA),[M,H]);
    EB=reshape(mean(RB),[H,N]);
    EAB=EA*EB;
    for i=1:1:n
        XX=reshape(X(i,:,:),[M,N]);
        for para=1:1:KKK
            A=reshape(RA(para,:,:),[M,H]);
            B=reshape(RB(para,:,:),[H,N]);
            pmodel(para)=prob(A*B,XX);
        end
        ccc(i)=log(mean(1./pmodel));
        www(i)=-log(mean(pmodel))+var(log(pmodel));
        d=M*H+N*H-H^2;
        aaa(i)=-log(mean(pmodel))+d/n;
        bbb(i)=-log(mean(pmodel))+(d/2)*log(n)/n;
        ddd(i)=log(prob(EAB,XX))-2*mean(log(pmodel));
    end
    cv(ttt,mmm)=mean(ccc-sss);
    wa(ttt,mmm)=mean(www-sss);
    ai(ttt,mmm)=mean(aaa-sss);
    bi(ttt,mmm)=mean(bbb-sss);
    di(ttt,mmm)=mean(ddd-sss);
    for i=1:1:nt
        XXT=reshape(XT(i,:,:),[M,N]);
        for para=1:1:KKK
            A=reshape(RA(para,:,:),[M,H]);
            B=reshape(RB(para,:,:),[H,N]);
            pmodel(para)=prob(A*B,XXT);
        end
        ggg(i)=-log(mean(pmodel));
    end
    ge(ttt,mmm)=mean(ggg-sst);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    [RA1 RB1]=gibbs(X1,n1,M,N,H,KKK,BURNIN,rho,mu,sigma,beta);

    for i=1:1:n1
        XX1=reshape(X1(i,:,:),[M,N]);
        for para=1:1:KKK
            A1=reshape(RA1(para,:,:),[M,H]);
            B1=reshape(RB1(para,:,:),[H,N]);
            pmodel1(para)=prob(A1*B1,XX1);
        end
        ccc1(i)=log(mean(1./pmodel1));
    end
    
    for i=1:1:n2
        XX2=reshape(X2(i,:,:),[M,N]);
        for para=1:1:KKK
            A1=reshape(RA1(para,:,:),[M,H]);
            B1=reshape(RB1(para,:,:),[H,N]);
            pmodel2(para)=prob(A1*B1,XX2);
        end
        hhh(i)=-log(mean(pmodel2));
    end
    
    ho(ttt,mmm)=(n1/n)*mean(hhh-sss2);
    ac(ttt,mmm)=(n1/n)*((n1/n)*mean(ccc1-sss1)+(n2/n)*mean(hhh-sss2));
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    fprintf('%g H=%g,ge=%.03f,cv=%.03f, wa=%.03f, ho=%.03f, ac=%.03f, ai=%.03f, di=%.03f, bi=%.03f,\n',...
        ttt,H,...
        ge(ttt,mmm),cv(ttt,mmm),wa(ttt,mmm),ho(ttt,mmm),ac(ttt,mmm),ai(ttt,mmm),di(ttt,mmm),bi(ttt,mmm));
  end
end

save('BayesTheory01.mat');
   


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




function [RA RB]=gibbs(X,n,M,N,H,KKK,BURNIN,rho,mu,sigma,beta)

    XX=reshape(sum(X),[M,N]);
    VX1=reshape(XX,[M*N,1]);
    VX2=reshape(XX',[M*N,1]);
    A=randn(M,H)/sqrt(M*H);
    TA=zeros(N*M,N*H);
    TB=zeros(M*N,M*H);
    RA=zeros(KKK,M,H);
    RB=zeros(KKK,H,N);
    for mcmc=1:1:KKK+BURNIN
        TA=zeros(M*N,N*H);
        for nnn=1:1:N
            TA((nnn-1)*M+1:1:nnn*M,(nnn-1)*H+1:1:nnn*H)=A;
        end
        S1=(1/rho^2)*eye(N*H,N*H)+beta*n/sigma^2*TA'*TA;
        S1=(S1+S1')/2;
        U1=(beta/sigma^2)*TA'*VX1;
        VB=mvnrnd(inv(S1)*U1,inv(S1));
        B=reshape(VB,[H,N]);
        BB=B';
        TB=zeros(M*N,M*H);
        for nnn=1:1:M
            TB((nnn-1)*N+1:1:nnn*N,(nnn-1)*H+1:1:nnn*H)=BB;
        end
        S2=(1/mu^2)*eye(M*H,M*H)+beta*n/sigma^2*TB'*TB;
        S2=(S2+S2')/2;
        U2=(beta/sigma^2)*TB'*VX2;
        VAT=mvnrnd(inv(S2)*U2,inv(S2));
        AT=reshape(VAT,[H,M]);
        A=AT';
        if(mcmc>BURNIN)
            RA(mcmc-BURNIN,:,:)=A;
            RB(mcmc-BURNIN,:,:)=B;
        end
    end
end
