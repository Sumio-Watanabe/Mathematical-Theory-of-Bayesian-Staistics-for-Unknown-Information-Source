clear;
%%% Matrix Factorization WBIC
n=200;
M=8;
N=8;
H0=2;
MAXH=6;
sigma=1;
rho=10;
mu=10;
beta=1/log(n);
TTT=200;
KKK=2000;
BURNIN=200;

rng(1);

CCCCC=(2*pi*sigma^2)^(M*N/2);
prob=@(AB,X)(CCCCC*exp(-sum(sum((X-AB).^2))/(2*sigma^2)));
A0B0=zeros(M,N);

for i=1:1:H0
    A0B0(i,i)=1;
end


for ttt=1:1:TTT

  for i=1:1:n
    X(i,:,:)=sigma*randn(M,N)+A0B0;
  end

  for mmm=1:1:MAXH
    H=mmm;
    [RA RB]=gibbs(X,n,M,N,H,KKK,BURNIN,rho,mu,sigma,beta);
    
     Y=reshape(sum(X),[M,N])';
     Q=(1/n)*Y'*Y;
     [V D]=eigs(Q,H);
     MLE=(1/n)*V*V'*Y';
      
    for i=1:1:n
      XXX=reshape(X(i,:,:),[M,N]);
      sss(i)=-log(prob(A0B0,XXX));
      bbb(i)=-mean(log(prob(MLE,XXX)));
      for para=1:1:KKK
        A=reshape(RA(para,:,:),[M,H]);
        B=reshape(RB(para,:,:),[H,N]);
        pmodel(i,para)=prob(A*B,XXX);
      end
      wb(i)=-mean(log(pmodel(i,:)));
    end
    wbic(ttt,mmm)=mean(wb-sss);
  
    d=M*H+N*H-H^2;
    bic(ttt,mmm)=mean(bbb-sss)+(d/2)*log(n)/n;
    h0=min(H0,H);
    h=H;
    if(mod(M+N+h+h0,2)==0)
        lambda=((2*(h+h0)*(M+N)-(M-N)^2-(h+h0)^2))/8; %%% even case 
    else
        lambda=((2*(h+h0)*(M+N)-(M-N)^2-(h+h0)^2)+1)/8; %%% even case 
    end
    theo(ttt,mmm)=mean(bbb-sss)+lambda*log(n)/n;
    fprintf('[%g] H=%g,wbic=%f,bic=%f,theo=%f\n',ttt,H,wbic(ttt,mmm),bic(ttt,mmm),theo(ttt,mmm));
  end
end

save('BayesTheory02.mat');

function [RA RB]=gibbs(X,n,M,N,H,KKK,BURNIN,rho,mu,sigma,beta)

  XX=reshape(sum(X),[M,N]);
  VX1=reshape(XX,[M*N,1]);
  VX2=reshape(XX',[M*N,1]);
  A=randn(M,H)/sqrt(M*H);
  TA=zeros(N*M,N*H);
  TB=zeros(M*N,M*H);
  RA=zeros(KKK,M,H);
  RB=zeros(KKK,H,N);
  
  for kkk=1:1:KKK+BURNIN
    
    TA=zeros(M*N,N*H);   
    for nnn=1:1:N
        TA((nnn-1)*M+1:1:nnn*M,(nnn-1)*H+1:1:nnn*H)=A;
    end
    S1=(1/rho^2)*eye(N*H,N*H)+beta*n/sigma^2*TA'*TA;
    S1=(S1+S1')/2;
    U1=(beta/sigma^2)*TA'*VX1;
    VB=mvnrnd(inv(S1)*U1,inv(S1));
    B=reshape(VB,[H,N]);
    BB=B';
    TB=zeros(M*N,M*H);
    for nnn=1:1:M
        TB((nnn-1)*N+1:1:nnn*N,(nnn-1)*H+1:1:nnn*H)=BB;
    end
    S2=(1/mu^2)*eye(M*H,M*H)+beta*n/sigma^2*TB'*TB;
    S2=(S2+S2')/2;
    U2=(beta/sigma^2)*TB'*VX2;
    VAT=mvnrnd(inv(S2)*U2,inv(S2));
    AT=reshape(VAT,[H,M]);
    A=AT';
    if(kkk>BURNIN)
      RA(kkk-BURNIN,:,:)=A;
      RB(kkk-BURNIN,:,:)=B;
    end
  end
end




