clear;

load('BayesTheory03.mat');

for ttt=1:1:TTT
    [mgg(ttt),agg(ttt)]=min(gg0(ttt,:));
    [mcv(ttt),acv(ttt)]=min(cv0(ttt,:));
    [mwa(ttt),awa(ttt)]=min(wa0(ttt,:));
    [mho(ttt),aho(ttt)]=min(ho1(ttt,:));
    [mas(ttt),aac(ttt)]=min(ac1(ttt,:));
    [mai(ttt),aai(ttt)]=min(ai0(ttt,:));
    [mdi(ttt),adi(ttt)]=min(di0(ttt,:));
    [mff(ttt),aff(ttt)]=min(fff(ttt,:));
    selected_gg(ttt)=gg0(ttt,agg(ttt))-ST(ttt,agg(ttt));
    selected_cv(ttt)=gg0(ttt,acv(ttt))-ST(ttt,acv(ttt));
    selected_wa(ttt)=gg0(ttt,awa(ttt))-ST(ttt,awa(ttt));
    selected_ho(ttt)=gg0(ttt,aho(ttt))-ST(ttt,aho(ttt));
    selected_ac(ttt)=gg0(ttt,aac(ttt))-ST(ttt,aac(ttt));
    selected_ai(ttt)=gg0(ttt,aai(ttt))-ST(ttt,aai(ttt));
    selected_di(ttt)=gg0(ttt,adi(ttt))-ST(ttt,adi(ttt));
    selected_ff(ttt)=gg0(ttt,aff(ttt))-ST(ttt,aff(ttt));
end


[egg,earg]=min(mean(gg0-ST)); %% If the optimal hyperparameter is known
fprintf('GE: %f,%f\n',mean(gg0(:,earg)-ST(:,earg)),std(gg0(:,earg)-ST(:,earg)));
fprintf('\n');
fprintf('GE: %f &    & %f  &%f \n',HYPER(earg),mean(gg0(:,earg)-ST(:,earg)),std(gg0(:,earg)-ST(:,earg)));
fprintf('CV: %f & %f & %f & %f\n',mean(HYPER(acv)),std(HYPER(acv)),mean(selected_cv),std(selected_cv));
fprintf('WA: %f & %f & %f & %f\n',mean(HYPER(awa)),std(HYPER(awa)),mean(selected_wa),std(selected_wa));
fprintf('HO: %f & %f & %f & %f\n',mean(HYPER(aho)),std(HYPER(aho)),mean(selected_ho),std(selected_ho));
fprintf('AC: %f & %f & %f & %f\n',mean(HYPER(aac)),std(HYPER(aac)),mean(selected_ac),std(selected_ac));
fprintf('AI: %f & %f & %f & %f\n',mean(HYPER(aai)),std(HYPER(aai)),mean(selected_ai),std(selected_ai));
fprintf('DI: %f & %f & %f & %f\n',mean(HYPER(adi)),std(HYPER(adi)),mean(selected_di),std(selected_di));
fprintf('FF: %f & %f & %f & %f\n',mean(HYPER(aff)),std(HYPER(aff)),mean(selected_ff),std(selected_ff));
fprintf('cv %f\n',mean((HYPER(earg)-HYPER(acv)).^2)^(1/2));
fprintf('wa %f\n',mean((HYPER(earg)-HYPER(awa)).^2)^(1/2));
fprintf('ho %f\n',mean((HYPER(earg)-HYPER(aho)).^2)^(1/2));
fprintf('ac %f\n',mean((HYPER(earg)-HYPER(aac)).^2)^(1/2));
fprintf('ai %f\n',mean((HYPER(earg)-HYPER(aai)).^2)^(1/2));
fprintf('di %f\n',mean((HYPER(earg)-HYPER(adi)).^2)^(1/2));
fprintf('ff %f\n',mean((HYPER(earg)-HYPER(aff)).^2)^(1/2));

