clear;

%%%%% Hyperparameter Optimization Polynomial Regression 

rng(1);

%%% p(y|x,w)=exp(-(s/2)(y-sum_{k=1}^N a_k x^(k-1))^2)
%%% prior(w)=(1/Z) s^(b-1)exp(-cs-ds||a||^2/2)
%%% b>N1/2 proper
n=20;
n1=10;
n2=n-n1;
nt=2000;
TTT=200;
K=2000;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MAXN=20;
s0=25;
%%%%%%%%%%% b0=MAXN/2+1;
c0=0.01;
d0=0.01;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
regressionf=@(x)(1-x/5+x.^2/30);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for ttt=1:1:TTT
    
  if(mod(ttt,2)==0)
      fprintf('%g\n',ttt);
  end
  XT=randn(nt,1);
  YT=regressionf(XT)+1/sqrt(s0)*randn(nt,1);
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  X=randn(n,1);
  Y=regressionf(X)+1/sqrt(s0)*randn(n,1);
  X1=X(1:1:n1,1);
  X2=X(n1+1:1:n,1);
  Y1=Y(1:1:n1,1);
  Y2=Y(n1+1:1:n,1);
  
  for mm=1:1:MAXN
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Sn(ttt,mm)=-(1/2)*log(s0/(2*pi))+(s0/(2))*mean((Y-regressionf(X)).^2);
    ST(ttt,mm)=-(1/2)*log(s0/(2*pi))+(s0/(2*nt))*sum((YT-regressionf(XT)).^2);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    N1=3;
    b0=mm/2-3.5; %%% 
    HYPER(mm)=b0;
    DIM0=ones(n,1)*(0:1:N1-1);
    DIM1=ones(n1,1)*(0:1:N1-1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    f0=(X*ones(1,N1)).^DIM0;
    A0=f0'*f0+d0*eye(N1,N1);
    B0=Y'*f0;
    C0=sum(Y.^2);
    D0=c0+(1/2)*(C0-B0*inv(A0)*B0');
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    s=gamrnd(b0-N1/2+n/2,1/D0,1,K);
    a=A0\B0'*ones(1,K)+mvnrnd(zeros(N1,1),inv(A0),K)'.*sqrt(1./s);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Ea=mean(a,2);
    Es=mean(s,2);
    ppp0=@(x,y,a,s)((s/(2*pi)).^(1/2).*exp(-(s/2).*(y-(x.^(0:1:N1-1))*a).^2));
    for i=1:1:n
      pred0(i)=log(mean(1./ppp0(X(i),Y(i),a,s)));
      train0(i)=-log(mean(ppp0(X(i),Y(i),a,s)));
      vvv0(i)=var(log(ppp0(X(i),Y(i),a,s)));
      dd10(i)=-log(ppp0(X(i),Y(i),Ea,Es));
      dd20(i)=-mean(log(ppp0(X(i),Y(i),a,s)));
    end
    cv0(ttt,mm)=mean(pred0);
    wa0(ttt,mm)=mean(train0)+mean(vvv0);
    ai0(ttt,mm)=mean(train0)+(N1+1)/n;
    di0(ttt,mm)=-mean(dd10)+2*mean(dd20);
    
 
    for i=1:1:nt
      test0(i)=-log(mean(ppp0(XT(i),YT(i),a,s)));
    end
    gg0(ttt,mm)=mean(test0);
    if(b0>N1/2)
      free=(n/2)*log(2*pi)...
        -gammaln(b0+n/2-N1/2)+gammaln(b0-N1/2)...
        +(1/2)*log(det(A0))-(N1/2)*log(d0)...
        +(b0+n/2-N1/2)*log(D0)-(b0-N1/2)*log(c0);
      fff(ttt,mm)=free/n;
    else 
      fff(ttt,mm)=NaN;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    f1=(X1*ones(1,N1)).^DIM1;
    A1=f1'*f1+d0*eye(N1,N1);
    B1=Y1'*f1;
    C1=sum(Y1.^2);
    D1=c0+(1/2)*(C1-B1*inv(A1)*B1');
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    s1=gamrnd(b0-N1/2+n1/2,1/D1,1,K);
    a1=A1\B1'*ones(1,K)+mvnrnd(zeros(N1,1),inv(A1),K)'.*sqrt(1./s1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ppp1=@(x,y,a,s)((s/(2*pi)).^(1/2).*exp(-(s/2).*(y-(x.^(0:1:N1-1))*a).^2));
    for i=1:1:n1
      pred1(i)=log(mean(1./ppp1(X1(i),Y1(i),a1,s1)));
      train1(i)=-log(mean(ppp1(X1(i),Y1(i),a1,s1)));
      vvv1(i)=var(log(ppp1(X1(i),Y1(i),a1,s1)));
    end
    for i=1:1:n2
      oost1(i)=-log(mean(ppp1(X2(i),Y2(i),a1,s1)));
    end
    ho1(ttt,mm)=mean(oost1);
    ac1(ttt,mm)=(mean(pred1)+mean(oost1))/2;
  end
end

save('BayesTheory03.mat');

