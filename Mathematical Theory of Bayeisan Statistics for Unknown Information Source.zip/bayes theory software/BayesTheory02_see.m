
clear;

load('BayesTheory02.mat');

fprintf('H=2, H=6 \n');
fprintf('Theory & BIC & WBIC & Theory & BIC & WBIC\n');
fprintf('%.4f& %.4f &%.4f & %.4f & %.4f &%.4f\n',...
    mean(theo(:,2)),mean(bic(:,2)),mean(wbic(:,2)),...
    mean(theo(:,6)),mean(bic(:,6)),mean(wbic(:,6)));
fprintf('%.4f& %.4f &%.4f & %.4f & %.4f &%.4f\n',...
    std(theo(:,2)),std(bic(:,2)),std(wbic(:,2)),...
    std(theo(:,6)),std(bic(:,6)),std(wbic(:,6)));

select_theo=zeros(1,6);
select_bic=zeros(1,6);
select_wbic=zeros(1,6);
for ttt=1:1:TTT
    [vvv, aaa]=min(theo(ttt,:));
    select_theo(1,aaa)=select_theo(1,aaa)+1;
    [vvv, aaa]=min(bic(ttt,:));
    select_bic(1,aaa)=select_bic(1,aaa)+1;
    [vvv, aaa]=min(wbic(ttt,:));
    select_wbic(1,aaa)=select_wbic(1,aaa)+1;
end

fprintf('%g %g %g\n',select_theo(2),select_bic(2),select_wbic(2));




