clear;

load('bayesTheory01.mat');

H=2;
d=M*H+N*H-H^2;
resultdisp(ge(:,1),cv(:,1),wa(:,1),ho(:,1),ac(:,1),ai(:,1),di(:,1),d,n,M,N,H0,H);
H=6;
d=M*H+N*H-H^2;
resultdisp(ge(:,2),cv(:,2),wa(:,2),ho(:,2),ac(:,2),ai(:,2),di(:,2),d,n,M,N,H0,H);

function resultval=resultdisp(ge,cv,wa,ho,ac,ai,di,d,n,M,N,H0,H)

fprintf('   GE  &  ISCV  &   WAIC &    HO  &    AC  &   AIC  &   DIC \n');
fprintf('%.04f & %.04f & %.04f & %.04f & %.04f & %.04f & %.04f\n',...
    mean(ge),mean(cv),mean(wa),mean(ho),mean(ac),mean(ai),mean(di));
fprintf('%.04f & %.04f & %.04f & %.04f & %.04f & %.04f & %.04f\n',...
    std(ge),std(cv),std(wa),std(ho),std(ac),std(ai),std(di));
fprintf('       & %.04f & %.04f & %.04f & %.04f & %.04f & %.04f\n',...
mean((cv-ge).^2)^(1/2),...
mean((wa-ge).^2)^(1/2),...
mean((ho-ge).^2)^(1/2),...
mean((ac-ge).^2)^(1/2),...
mean((ai-ge).^2)^(1/2),...
mean((di-ge).^2)^(1/2));

if(mod(M+N+H+H0,2)==0)
  lambda=((2*(H+H0)*(M+N)-(M-N)^2-(H+H0)^2))/8; %%% even case 
else
  lambda=((2*(H+H0)*(M+N)-(M-N)^2-(H+H0)^2)+1)/8; %%% even case 
end

fprintf('Theory　　%0.4f, %0.4f\n',lambda/n, d/(2*n));

end


